console.log("HI this is running in a docker container");
