console.log("First stage in Docker Pipeline Running, Congratulations!");
var fs = require('fs');
var http = require('http');
var titles = [];

function extractMovieTitles() {
  var write = fs.createWriteStream('./ahab/output.json');
  var options = {
    host: 'www.myapifilms.com',
    path: '/imdb/inTheaters',
    method: 'GET'
  };
  var callback = function(response) {
		var str = "";
		response.on('data',function(chunk){
			str+=chunk;
		})
    response.on('end', function() {
			fs.writeFile('./ahab/output.json',str,function(res,err){
				console.log("There was a problem writing data to the output file");
				console.log(err);
			})
    })
  }
  http.request(options, callback).end();
  // var file = fs.createWriteStream('/ahab/output.json');
  // fs.readFile('/src/input.json','utf-8',function(err,data){
  // 	fs.writeFile('/ahab/output.json',data,function(err){
  // 		if(err){
  // 			console.log("\nERROR IN DOCKERTEST\n",err.message,err.stack.split('\n'));
  // 		}
  // 		console.log('DOCKERTEST FILE SAVED!')
  // 	})
  //
  // })
}

extractMovieTitles();
