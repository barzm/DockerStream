var fs = require('fs');
console.log("Running second pipeline repository. Congrats!");
fs.readFile('/data/output.json','utf-8',function(err,data){
	if(err) console.log("ERROR reading pipe 2",err)
	console.log('DATA IN PIPE #2', data);
})

// fs.readdir('/data',function(err,files){
// 	console.log("FILES IN DATA",files)
// 	for(var i=0; i<files.length; i++){
// 		console.log(files[i])
// 	}

// })

// fs.readdir('/',function(err,files){
// 	console.log("FILES IN /",files)
// 	for(var i=0; i<files.length; i++){
// 		console.log(files[i])
// 	}

// })
