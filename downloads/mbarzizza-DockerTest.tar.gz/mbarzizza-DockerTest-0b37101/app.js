console.log("First stage in Docker Pipeline Running, Congratulations!");
var fs = require('fs');
var titles = [];
function extractMovieTitles(){
	// var file = fs.createWriteStream('/ahab/output.json');
	fs.readFile('/src/input.json','utf-8',function(err,data){
		fs.writeFile('/ahab/output.json',data,function(err){
			if(err){
				console.log("\nERROR IN DOCKERTEST\n",err.message,err.stack.split('\n'));
			}
			console.log('DOCKERTEST FILE SAVED!')
		})

	})
}

extractMovieTitles();
