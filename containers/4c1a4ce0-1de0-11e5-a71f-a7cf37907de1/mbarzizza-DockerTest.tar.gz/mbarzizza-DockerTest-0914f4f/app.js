console.log("First stage in Docker Pipeline Running, Congratulations!");
